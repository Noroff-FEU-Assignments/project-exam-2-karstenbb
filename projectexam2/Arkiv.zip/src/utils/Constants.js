export const api_url = "https://evening-basin-37859.herokuapp.com";
export const AUTH_PATH = "/auth/local";
