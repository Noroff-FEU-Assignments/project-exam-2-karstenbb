import React from "react";
import ContactForm from "../components/ContactForm";

const Contact = () => {
  return (
    <>
      <ContactForm></ContactForm>
    </>
  );
};

export default Contact;
